news\_portal package
====================

Submodules
----------

news\_portal.asgi module
------------------------

.. automodule:: news_portal.asgi
   :members:
   :show-inheritance:
   :undoc-members:

news\_portal.settings module
----------------------------

.. automodule:: news_portal.settings
   :members:
   :show-inheritance:
   :undoc-members:

news\_portal.urls module
------------------------

.. automodule:: news_portal.urls
   :members:
   :show-inheritance:
   :undoc-members:

news\_portal.wsgi module
------------------------

.. automodule:: news_portal.wsgi
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: news_portal
   :members:
   :show-inheritance:
   :undoc-members:

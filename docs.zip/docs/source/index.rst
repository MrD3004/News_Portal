.. news_portal documentation master file, created by
   sphinx-quickstart on Wed Nov 26 11:39:07 2025.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

news_portal documentation
=========================

Welcome to the developer documentation for the **news_portal** Django project.  
This site contains API references, models, views, forms, and usage guides generated from docstrings.

Contents
--------

.. toctree::
   :maxdepth: 2
   :caption: Project Modules:

   modules
   news_portal
   articles

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`



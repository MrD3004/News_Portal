Project Modules
===============

This section provides an overview of the main Django apps and their modules.

.. toctree::
   :maxdepth: 2
   :caption: Packages

   articles
   news_portal

